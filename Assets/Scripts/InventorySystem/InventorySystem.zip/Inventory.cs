using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public static Inventory Instance { get; private set; }

    public List<InventorySlot> inventorySlots = new List<InventorySlot>();
    [Tooltip("Define the maximum number of slots")]
    public int maxSlots = 20;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void AddItem(Item item, int quantity = 1)
    {
        InventorySlot slot = inventorySlots.Find(i => i.item == item && item.isStackable);
        if (slot != null)
        {
            slot.quantity += quantity;
        }
        else
        {
            if (inventorySlots.Count < maxSlots)
            {
                inventorySlots.Add(new InventorySlot(item, quantity));
            }
            else
            {
                Debug.LogWarning("Inventory is full!");
            }
        }
    }

    public void RemoveItem(Item item, int quantity = 1)
    {
        InventorySlot slot = inventorySlots.Find(i => i.item == item);
        if (slot != null)
        {
            slot.quantity -= quantity;
            if (slot.quantity <= 0)
            {
                inventorySlots.Remove(slot);
            }
        }
    }
}

[System.Serializable]
public class InventorySlot
{
    public Item item;
    public int quantity;

    public InventorySlot(Item item, int quantity)
    {
        this.item = item;
        this.quantity = quantity;
    }
}
